from mininet.net import Mininet
from mininet.topo import Topo
from mininet.cli import CLI
from mininet.log import setLogLevel
from mininet.link import Link,TCLink

class MyTopo( Topo ):

    def build( self ):

        h1=net.addHost("h1",ip="192.168.1.1")
        h2=net.addHost("h2",ip="192.168.1.2")
        h3=net.addHost("h3",ip="192.168.1.3")
        r1=net.addSwitch("r1")
        r2=net.addSwitch("r2")

        net.addLink(r1,h1)
        net.addLink(r1,h2)
        net.addLink(r2,h3)
        net.build()
        CLI(net)
        net.stop()

topos = { 'mytopo': ( lambda: MyTopo() ) }
